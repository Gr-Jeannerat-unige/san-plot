function SIMPLE_DEMO()

path_of_experiments='./demo_nmr_data';
dataset='dj-caryophyllene_oxide';
exp_no=10;
exp_procno=1;

path_acqu =[ path_of_experiments '/' dataset '/'];

if exist([path_acqu '/' num2str(exp_no) '/pdata/' num2str(exp_procno) '/'] ,'dir')
   
    disp(['Reading    spectrum  ' dataset  '/' num2str(exp_no) '/pdata/' num2str(exp_procno)  ' ' ])
    
    data_set=read_data_bruker(path_acqu,exp_no,exp_procno);
    
    disp(['Workin on spectrum  ' dataset '/' num2str(exp_no) '/pdata/' num2str(exp_procno)  ' ' data_set.pulprog])
    if exist('limit_chemical_shift_f2','var')
        data_set.limit_chemical_shift_f2=limit_chemical_shift_f2;
    end
    if exist('limit_chemical_shift_f1','var')
        data_set.limit_chemical_shift_f1=limit_chemical_shift_f1;
    end
    if exist('dec_param','var')
        data_set.dec_param=dec_param;
    end
    mkdir('Results_paper_git')% in case does not exist

    %% determine noise level
    
     opt.fix_offset=1;
    opt.plot_results=1;%
    opt.fig_number=101;
    opt.up_to_this_number_of_time_noise_level=5;
    
    [data_set.noise_level, data_set.list_peaks, data_set.I0_offset, data_set.noise_levela , data_set.noise_leveln , data_set.noise_levelan, ...
        how_much_higher_than_noise_are_signals, where_determine_noise_level, sc_pow10, val_pow10, data_set.signal_shape] ...
        = get_noise_level(data_set,opt);
    %% correct the spectrum
    data_set.spectrum= data_set.spectrum-data_set.I0_offset;
    
    % % %
    % % %
    % % %     if ~isfield(data_set,'signal_shape')
    % % %         signal_shape= determine_signal_shape(data_set,opt.up_to_this_number_of_time_noise_level,1);%1 was ﻿loop_over_spectra
    % % %     else
    % % %         signal_shape=data_set.signal_shape;
    % % %     end
    % % %     if (size(data_set.signal_shape,1)>1) && (size(data_set.signal_shape,2)>1)
    % % %         %prepare distribution
    % % %         work_sp=real(signal_shape);
    % % %         work_sp=reshape(work_sp,size(work_sp,1)*size(work_sp,2),1);% transforms 2d matrix into a vector
    % % %         work_sp=sort(work_sp,'descend');% sort points
    % % %         [sc_pow10_sha,val_pow10_sha]=interp_log_distrib(work_sp',50);
    % % %         %prepare plot
    % % %         to_pt=round(min([size(sc_pow10_sha,2) size(sc_pow10,2)])/2);
    % % %         v1=log(val_pow10_sha(1,1:to_pt));
    % % %         v2=log(val_pow10(1:to_pt,1))';
    % % %         [~, pos_norm]=min((v2-v1));
    % % %         tmp_plot=val_pow10_sha*val_pow10(pos_norm,1)/val_pow10_sha(1,pos_norm);
    % % %         figure(10);loglog(sc_pow10_sha,tmp_plot,'DisplayName',['shape']);hold on  %    ),'DisplayName','Intensities (pos.)');
    % % %
    % % %
    % % %         loglog(sc_pow10_sha(pos_norm),val_pow10_sha(1,pos_norm)*val_pow10(pos_norm,1)/val_pow10_sha(1,pos_norm),'gx')
    % % %     end
    % % %     if ~exist('supp_ti','var')
    % % %         supp_ti=[num2str(data_set.acquno) '/' num2str(data_set.procno)];
    % % %     end
    % % %     figure(10);loglog(sc_pow10,val_pow10,'DisplayName',['S(+) ' supp_ti]);hold on  %    ));
    % % %
    % % %     %   pos_norm=round(0.4*size(val_pow10_window,2))+1;
    % % %
    % % %
    % % %     % red cross at max
    % % %     %  loglog(sc_pow10_window(pos_norm),val_pow10_window(1,pos_norm)*val_pow10(pos_norm,1)/val_pow10_window(1,pos_norm),'rx')
    % % %
    % % %
    % % %     %  figure(10);loglog(sc_pow10_window,val_pow10_window*val_pow10(1,1)/val_pow10_window(1,1),'r:','DisplayName',['wind']);hold on  %    ),'DisplayName','Intensities (pos.)');
    % % %     % figure(10);loglog(sc_pow10_window,val_pow10_window*val_pow10(pos_norm,1)/val_pow10_window(1,pos_norm),'DisplayName',['wind']);hold on  %    ),'DisplayName','Intensities (pos.)');
    % % %     %      figure(10);loglog(sc_pow10_window,val_pow10_window*val_pow10(pos_norm,1)/val_pow10_window(1,pos_norm),'k:','DisplayName',['wind. func.']);hold on  %    ),'DisplayName','Intensities (pos.)');
    % % %
    % % %     %
    % % %     %         if loop_over_spectra==8
    % % %     %             refir=val_pow10;
    % % %     %
    % % %     %             end
    % % %     %         % sum
    % % %     %    to_pt=min([size(sc_pow10_window,2) size(sc_pow10,2)]);
    % % %     %         ttmp=sc_pow10_window(1,1:to_pt);
    % % %     %         ttmp1=sc_pow10(1,1:to_pt);
    % % %     %
    % % %     %         tkmp=refir(1:to_pt,1)';
    % % %     %         trer=val_pow10_window(1,1:to_pt);
    % % %     %         to_plot=(tkmp.*trer);
    % % %     %         to_plot=to_plot*refir(pos_norm,1)/to_plot(1,pos_norm)
    % % %     %         figure(10);loglog(ttmp,to_plot,'k--','DisplayName',['sum']);hold on  %    ),'DisplayName','Intensities (pos.)');
    % % %
    % % %     drawnow;
    % % %     legend('Location','SouthWest');
    % % %     legend('off');
    % % %     %                 switch loop_over_spectra
    % % %     %                     case {13 17 }
    % % %     %                         last=1;
    % % %     %                 end
    % % %     set(findall(gca, 'Type', 'Line'),'LineWidth',1.5);
    % % %     y_dims=ylim;  ylim([1 y_dims(1,2)]);%set lower bound avoi showing long tail with very small values)
    % % %     fig= figure(10);
    % % %     set(fig,'PaperUnits' , 'centimeters');
    % % %     %  fig.PaperUnits = 'centimeters';
    % % %     %size of figure
    % % %     width_fig=18;
    % % %     width_fig=9;
    % % %     width_fig=12;
    % % %     height_fig=width_fig*2/3;
    % % %     %  fig.PaperPosition = [1 29-height_fig width_fig height_fig];% for vertical A4
    % % %     set(fig,'PaperPosition', [1 29-height_fig width_fig height_fig]);% for vertical A4 %DEVEL
    % % %     %                     fig.PaperOrientation = 'portrait';% portrait should be default...
    % % %     %                     fig.PaperType = 'a4';% portrait should be default...
    % % %     set(fig,'PaperOrientation','portrait');% portrait should be default...
    % % %     set(fig,'PaperType', 'a4');% portrait should be default...
    % % %     legend()
    % % %     if ~exist('dataset_name','var')
    % % %         dataset_name=['Dataset name : ' dataset];
    % % %     end
    % % %     title([dataset_name],'interpreter','none')
    % % %     drawnow;
    % % %     print('-depsc','-tiff','-r600',[ './Results_paper_git/Simple_demo_snr_' data_set.expname  '.eps']);%here
    % % %    % print('-dpdf',[ './Results_paper_git/Final_comparison_snr_' data_set.expname '.pdf']);%here
    % % %
    % % %
    % % %     %% plot spectrum...
    % % %     plot_2d_interp(data_set);
    % % %     fig=gcf;
    % % %     set(findall(gca, 'Type', 'Line'),'LineWidth',1.5);
    % % %     orient(fig,'landscape')
    % % %     proc_txt1='';
    % % %     proc_txt2='';
    % % %     if isfield(data_set,'td1')
    % % %         [~,~,proc_txt1]=window_function_Bruker(data_set,1);
    % % %     else
    % % %         [~,~,proc_txt1]=window_function_Bruker(data_set,2);
    % % %     end
    % % %     [~,~,proc_txt2]=window_function_Bruker(data_set,2);
    % % %
    % % %     titext= [num2str(data_set.expname) ' ' num2str(data_set.acquno)  ' ' num2str(data_set.procno)  ' (' data_set.pulprog(2:end-1) ') ' proc_txt1 proc_txt2];
    % % %     title(titext,'Interpreter','none');
    % % %     set(fig,'PaperUnits' , 'centimeters');
    % % %     %    fig.PaperUnits = 'centimeters';
    % % %     % fig.PaperPosition = [3 10 15 10];
    % % %     set(fig,'PaperPosition' ,[3 10 15 10]);
    % % %
    % % %     drawnow;
    % % %     print('-depsc',['./Results_paper_git/Simple_demo_' data_set.expname '_' num2str(data_set.acquno)  '_' num2str(data_set.procno) '_'  '.eps']);%here
else
    error(['folder  ' path_acqu '/' num2str(exp_no) '/pdata/' num2str(exp_procno) '/  does not exist !' ])
    
end

end
