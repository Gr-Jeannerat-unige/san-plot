function [x] = simple_norminv(in)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
x = -sqrt(2).*erfcinv(2*in);

end

